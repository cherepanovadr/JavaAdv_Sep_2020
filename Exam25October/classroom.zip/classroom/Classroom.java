package classroom;

import java.util.ArrayList;
import java.util.List;

public class Classroom {
    public List<Student> students;
    public int capacity;

    public Classroom(int capacity) {
        this.capacity = capacity;
        this.students = new ArrayList<>();
    }

    public List<Student> getStudents() {
        return students;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getStudentCount() {
        return this.students.size();
    }


    public String registerStudent(Student student) {
        String out = "";
        if (getCapacity() > getStudentCount()) {
            if (students.contains(student)) {
                out = String.format("Student is already in the classroom");
            } else {
                students.add(student);
                out = String.format("Added student %s %s", student.getFirstName(), student.getLastName());
            }
        } else {
            out = String.format("No seats in the classroom");
        }
        return out;
    }

    public String dismissStudent(Student student) {
        String out = "";
        boolean Found = false;
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).equals(student)) {
                out = String.format("Removed student %s %s", student.getFirstName(), student.getLastName());
                this.students.remove(i);
                Found = true;
            }
        }

        if (!Found) {
            out = String.format("Student not found");
        }
        return out;
    }

    public String getSubjectInfo(String sub) {
        boolean Found = false;
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Subject: %s", sub));
        sb.append(System.lineSeparator());
        sb.append("Students:");
        sb.append(System.lineSeparator());
        for (Student student1 : students) {
            if (student1.getBestSubject().equals(sub)) {
                sb.append(String.format("%s %s", student1.getFirstName(), student1.getLastName()));
                sb.append(System.lineSeparator());

                Found = true;
            }
        }
        if (!Found) {
            return "No students enrolled for the subject";
        } else {
            return sb.toString().trim();
        }
    }

    public Student getStudent(String dean, String winchester) {
        for (Student student : this.students) {
            if (student.getFirstName().equals(dean) && student.getLastName().equals(winchester)) {
                return student;
            }
        }
        return null;
    }

    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Classroom size: %d", getStudentCount()));
        sb.append(System.lineSeparator());
        for (Student student : students) {
            sb.append("==" + student.toString());
            sb.append(System.lineSeparator());
        }
        return sb.toString().trim();
    }
}
